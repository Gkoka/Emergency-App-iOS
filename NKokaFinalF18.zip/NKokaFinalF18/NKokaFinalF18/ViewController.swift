//
//  ViewController.swift
//  NKokaFinalF18
//
//  Created by Naga Gayatri Koka on 12/6/18.
//  Copyright © 2018 Naga Gayatri Koka. All rights reserved.
//

import UIKit
import MapKit
import MessageUI
import CoreLocation

class ViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate, MFMailComposeViewControllerDelegate
{
    @IBOutlet weak var mapView: MKMapView!
    @IBOutlet weak var latitudeLabel: UILabel!
    @IBOutlet weak var longitudeLabel: UILabel!
    
    let locMgr = CLLocationManager()
    
    /* This function tells the delegate to get the user's permission to use his/her location. */
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        //switch statement for status
        switch  status {
        case .denied, .restricted:
            print("no authorization")
        case .notDetermined:
            locMgr.requestWhenInUseAuthorization()
        default: // Good to go
            locMgr.startUpdatingLocation()
        }//end switch
    }//end func
 
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        // Get the new location
        let newLocation = locations[0]
        
        // Display the location on the map
        self.mapView.showsUserLocation = true
        
        self.latitudeLabel.text = "\(newLocation.coordinate.latitude)"
        
        self.longitudeLabel.text = "\(newLocation.coordinate.longitude)"
        
        let span:MKCoordinateSpan = MKCoordinateSpanMake(0.05, 0.05)
        let currentLocation:CLLocationCoordinate2D = CLLocationCoordinate2DMake(newLocation.coordinate.latitude, newLocation.coordinate.longitude)
        let region:MKCoordinateRegion = MKCoordinateRegionMake(currentLocation, span)
        mapView.setRegion(region, animated: true)
        
        // Just want to know the user's moving speed
        print(newLocation.coordinate.latitude, newLocation.coordinate.longitude)
    }//end func
    
    @IBAction func CallButton1(_ sender: UIButton)
    {
        //Guard statement to retrieve the phone number on the button title
        let num1 = 18157536942
        
        //Load the phone number into myURL
        let myURL:NSURL = URL(string: "tel://\(num1)")! as NSURL
        
        //Send the phone number to phoneCall app.
        UIApplication.shared.open(myURL as URL, options:[:], completionHandler: nil)
    }
    
    @IBAction func CallButton2(_ sender: UIButton)
    {
        //Guard statement to retrieve the phone number on the button title
        let num2 = 911
        
        //Load the phone number into myURL
        let myURL:NSURL = URL(string: "tel://\(num2)")! as NSURL
        
        //Send the phone number to phoneCall app.
        UIApplication.shared.open(myURL as URL, options:[:], completionHandler: nil)
    }
    
    @IBAction func shareLocation(_ sender: UIButton)
    {
        let actionSheet = UIAlertController(title: "SEND MY LOCATION", message: "For CSCI521 Students. Use UIActivityViewController for send to Social Media", preferredStyle: .actionSheet)
        
        let cancel = UIAlertAction(title: "CANCEL", style: .cancel, handler: nil)
        
        let sendEmail = UIAlertAction(title: "Send Email", style: .default, handler: {action in
            
            //Load the mail view controller
            let mailComposeVC = MFMailComposeViewController()
            
            //Make it as it's own delegate
            mailComposeVC.mailComposeDelegate = self
            
            //Set the recipents
            let toRecipents = ["niucsci@gmail.com"]
            
            //set the title
            let emailTitle = "NKokaFinalF18"
            
            //Set the message body
            let messageBody = "Please help! Latitude: \(self.mapView.userLocation.coordinate.latitude),Longitude: \(self.mapView.userLocation.coordinate.longitude) Naga Gayatri, Koka, Z1823454."
            
            //Load the recipents into the framework
            mailComposeVC.setToRecipients(toRecipents)
            
            //Load the subject into the framework
            mailComposeVC.setSubject(emailTitle)
            
            //Load the message body into the framework
            mailComposeVC.setMessageBody(messageBody, isHTML: false)
            
            //Present the framework on the screen
            self.present(mailComposeVC, animated: true, completion: nil)
            
        })
        
        let sendMedia = UIAlertAction(title: "Send to Social Meida", style: .default, handler: { action in
            
            let activityController = UIActivityViewController.init(activityItems: ["Please help!","Latitude: \(self.mapView.userLocation.coordinate.latitude)","Longitude: \(self.mapView.userLocation.coordinate.longitude)","Naga Gayatri Koka, Z1823454"], applicationActivities: nil)
            self.present(activityController,animated: true)
        })
        
        actionSheet.addAction(sendEmail)
        actionSheet.addAction(sendMedia)
        actionSheet.addAction(cancel)
        
        present(actionSheet,animated: true, completion: nil)
    }
    
    //When a send button is pressed then dismiss the mail view
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?)
    {
        self.dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Making a deleagte as it self
        locMgr.delegate = self
        //Making map view delegate as self
        self.mapView.delegate = self
        
        // Prepare to get the best accuracy for the user's location.
        locMgr.desiredAccuracy = kCLLocationAccuracyBest
        // Ask the user before obtaining his/her location data since it is a private data.
        locMgr.requestWhenInUseAuthorization()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

